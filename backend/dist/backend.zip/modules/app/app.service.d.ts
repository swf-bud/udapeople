export declare class AppService {
    root(): string;
}
