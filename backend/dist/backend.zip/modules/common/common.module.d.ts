import { OnModuleInit } from '@nestjs/common';
export declare class CommonModule implements OnModuleInit {
    constructor();
    onModuleInit(): void;
}
