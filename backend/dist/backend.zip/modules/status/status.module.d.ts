export declare class StatusModule {
}
