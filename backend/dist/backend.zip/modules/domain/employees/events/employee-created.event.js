"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class EmployeeCreated {
    constructor(employeeId, firstName) {
        this.employeeId = employeeId;
        this.firstName = firstName;
    }
}
exports.EmployeeCreated = EmployeeCreated;
//# sourceMappingURL=employee-created.event.js.map