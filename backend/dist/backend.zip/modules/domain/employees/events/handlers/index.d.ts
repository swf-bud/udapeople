import { NotifyEmployeeCreatedConsole } from './notify-employee-created-console.handler';
export declare const EventHandlers: (typeof NotifyEmployeeCreatedConsole)[];
