"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeBirthdate {
    constructor(employeeId, birthdate) {
        this.employeeId = employeeId;
        this.birthdate = birthdate;
    }
}
exports.UpdateEmployeeBirthdate = UpdateEmployeeBirthdate;
//# sourceMappingURL=update-employee-birthdate.command.js.map