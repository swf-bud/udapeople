"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeEffectiveDate {
    constructor(employeeId, effectiveDate) {
        this.employeeId = employeeId;
        this.effectiveDate = effectiveDate;
    }
}
exports.UpdateEmployeeEffectiveDate = UpdateEmployeeEffectiveDate;
//# sourceMappingURL=update-employee-effective-date.command.js.map