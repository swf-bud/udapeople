"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeTags {
    constructor(employeeId, tags) {
        this.employeeId = employeeId;
        this.tags = tags;
    }
}
exports.UpdateEmployeeTags = UpdateEmployeeTags;
//# sourceMappingURL=update-employee-tags.command.js.map