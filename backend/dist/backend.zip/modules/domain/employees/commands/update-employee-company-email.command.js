"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeCompanyEmail {
    constructor(employeeId, companyEmail) {
        this.employeeId = employeeId;
        this.companyEmail = companyEmail;
    }
}
exports.UpdateEmployeeCompanyEmail = UpdateEmployeeCompanyEmail;
//# sourceMappingURL=update-employee-company-email.command.js.map