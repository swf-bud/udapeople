"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ActivateEmployee {
    constructor(employeeId, isActive) {
        this.employeeId = employeeId;
        this.isActive = isActive;
    }
}
exports.ActivateEmployee = ActivateEmployee;
//# sourceMappingURL=activate-employee.command.js.map