"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeName {
    constructor(employeeId, firstName, middleName, lastName, secondLastName) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.secondLastName = secondLastName;
    }
}
exports.UpdateEmployeeName = UpdateEmployeeName;
//# sourceMappingURL=update-employee-name.command.js.map