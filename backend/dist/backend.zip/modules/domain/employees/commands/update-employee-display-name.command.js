"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeDisplayName {
    constructor(employeeId, displayName) {
        this.employeeId = employeeId;
        this.displayName = displayName;
    }
}
exports.UpdateEmployeeDisplayName = UpdateEmployeeDisplayName;
//# sourceMappingURL=update-employee-display-name.command.js.map