"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UpdateEmployeeSalaryType {
    constructor(employeeId, salaryType) {
        this.employeeId = employeeId;
        this.salaryType = salaryType;
    }
}
exports.UpdateEmployeeSalaryType = UpdateEmployeeSalaryType;
//# sourceMappingURL=update-employee-salary-type.command.js.map