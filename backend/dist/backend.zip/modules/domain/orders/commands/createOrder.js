"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CreateOrder {
    constructor(productId, productQuantity, userId) {
        this.productId = productId;
        this.productQuantity = productQuantity;
        this.userId = userId;
    }
}
exports.CreateOrder = CreateOrder;
//# sourceMappingURL=createOrder.js.map