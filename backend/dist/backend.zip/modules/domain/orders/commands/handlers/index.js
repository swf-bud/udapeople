"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const orderCreator_1 = require("./orderCreator");
exports.CommandHandlers = [orderCreator_1.OrderCreator];
//# sourceMappingURL=index.js.map