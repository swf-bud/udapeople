import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class FixProductIdTable1549398619849 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<any>;
    down(queryRunner: QueryRunner): Promise<any>;
}
