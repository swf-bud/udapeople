import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddOrders1549375960026 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<any>;
    down(queryRunner: QueryRunner): Promise<any>;
}
